module.exports = {
  env: {
    API_URL: "http://103.139.75.95:5555",
  },
};
